## Tradução [CodeIgniter v2.2.0](https://github.com/bcit-ci/CodeIgniter/tree/2.2-stable)

Neste repositório contém traduções de:

 * Core
 * Libraries
 * Helpers

## Contribuição
Fique totalmente a vontade para contribuir e ajudar em novas traduções e correções.

## Licença

[MIT License](http://dhyegofernando.mit-license.org/) © Dhyego Fernando
